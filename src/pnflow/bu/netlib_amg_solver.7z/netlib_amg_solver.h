#ifndef SOLVER_H
#define SOLVER_H


///. to define 'integer'
#include "netlib_amg_1995_prototypes.h"

class Element;


class amg_solver : public Solver
{

public:
 
    amg_solver(const vector<Element*>& network, const vector<Element*>& inlet, const vector<Element*>& outlet,
        int outletIdx, int maxNonZeros, int debugMode, string matFileName, bool matlabFormat);
 
    //~ amg_solver(const amg_solver& slover);
    ~amg_solver();

	double flowrate(double inPrs, double outPrs, const Fluid& fluid, double& flowErr, double& elap,
		double satWat = 1.0, bool writeVelocity = false, bool writeMat = false, bool resistivitySolve = false);

	double PotetionalDifference(double inPrs, double outPrs, const Fluid& fluid, double& flowErr, double& elap,
		double satWat = 1.0, bool writeVelocity = false, bool writeMat = false, bool resistivitySolve = false);


	static void initSolver(double eps, int scaleFact, int slvrOutput, bool verboseSlvr, bool useGrav);

	const vector< pair<const Element*, double> > & throatConductances() const {return    m_throatConductances;}

private:

	double getSP(const Fluid*, double&, int&, bool) const;
	void fillMatrixSP(double, double, const Fluid *, bool writeVelocity, bool resistivitySolve);

	double getFlowRate(const Fluid*, double&, int&, bool) const;
	void fillMatrix(double, double, const Fluid *, bool writeVelocity, bool resistivitySolve);



	//~ void dumpMatrixMatlab(const string& fileName) const;
    //~ void dumpMatrixStd(const string& fileName) const;
    //~ void readMatrixStd(const string& fileName);
	//~ void dumpVelocityStd(const string& fileName, const Fluid* fluid, bool resistivitySolve) const;
	//~ void dumpVelocityMatlab(const string& fileName, const Fluid* fluid, bool resistivitySolve) const;
	//~ void writeVelocityEntry(ostream& out, pair<const Element*, double> entry, const Fluid* fluid, bool resistivitySolve) const;

    static integer                                              MAT_MEM_SCALE;
    static bool                                             INITIALISED;
    static bool                                             USE_GRAVITY;
    static integer                                             SYMMETRIC_MAT;
    static integer                                             SLVR_OUTPUT;
    static double                                           TOLERANCE;
    static integer                                             VERBOSE_SLVR;
    static const double                                     SCALE_FACTOR;
    static const double                                     SCALE_FACTORSP;

    const int                                     			m_debugMode;

    const vector<Element*>&                              m_elems;
    const vector<Element*>&                              m_inPores;
    const vector<Element*>&                              m_outPores;
    const int                                               m_numPoresp1;
    const int                                               m_maxNonZeros;      // of the network model
    const string                                            m_matrixFileName;
    //~ const bool                                              m_matlabFormat;
    const int                                               m_probSize;         // Constant values given by the size
    const integer                                              m_matElemFactor;
    const integer                                              m_matSizeFactor;

    vector< FourSome<int, double, double, double> >         m_networkOutlets;
    vector< FourSome<int, double, double, double> >         m_networkInlets;
	vector< pair<const Element*, double> >			        m_throatConductances;

    mutable int                                            m_petscErr;
    integer                                                    m_nMatrixRows;
    integer                                                   m_nonZeroElems;
    integer                                                    *m_rowFirstEntryInd;
    integer                                                    *m_iColumn;
    integer                                                    *m_someIdxBuffer;
    integer                                                    *m_colHash;
    integer                                                    m_nMatrixEntries;

    double                                                 *m_matElems;
    double                                                 *m_rhsVecBuffer;
    double                                                 *m_solVecBuffer;

    Pore                                                   **m_poreHash;
};


#endif
