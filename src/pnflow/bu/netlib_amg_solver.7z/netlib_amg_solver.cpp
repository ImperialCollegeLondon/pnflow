#ifdef WIN32
#pragma warning(disable:4786)
#endif

#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <string>
#include <cassert>
#include <algorithm>
//~ #include <functional>
//~ #include <set>
//~ #include <utility>
//~ #include <vector>
//~ #include <ctime>
//~ #include <typeinfo>
//~ #include <map>
using namespace std;


//~ #include "sortedEvents.h"
//~ #include "threeSome.h"
//~ #include "inputData.h"
//~ #include "fluid.h"
//~ #include "node.h"
//~ #include "elem_Model.h"
#include "Element.h"
//~ #include "compareFuncs.h"
#include "solver.h"

const double            amg_solver::SCALE_FACTOR = 1.0e18;
integer                     amg_solver::MAT_MEM_SCALE = 3;
bool                    amg_solver::INITIALISED = false;
bool                    amg_solver::USE_GRAVITY = false;
integer                    amg_solver::SYMMETRIC_MAT = 22;
integer                    amg_solver::SLVR_OUTPUT = 10;
integer                    amg_solver::VERBOSE_SLVR = 11111;
double                  amg_solver::TOLERANCE = 1.0E-29;




/**
// This is the constructor for the solver class. Given the network it allocates memory
// for various C type arrays. These are set to the maximum length possible which is when
// all pores contain the fluid for which the flowrate is going to be obtained.
*/
amg_solver::amg_solver(const vector<Element*>& network, const vector<Element*>& inlet, const vector<Element*>& outlet,
               int outletIdx, int maxNonZeros, int debugMode, string matFileName, bool matlabFormat) 
 : m_debugMode(debugMode), m_elems(network), m_inPores(inlet), m_outPores(outlet), m_numPoresp1(outletIdx), m_maxNonZeros(maxNonZeros),
   m_matrixFileName(matFileName), m_probSize(outletIdx-1), m_matElemFactor(3),
    //~ m_matlabFormat(matlabFormat),
   m_matSizeFactor(5)
{
    int maxNdaFactor = (m_matElemFactor*m_maxNonZeros) +
        m_probSize * (m_matSizeFactor*MAT_MEM_SCALE);

    m_matElems = new double[maxNdaFactor+597]+97;         // These are all set to maximum number of non zero elements, ie
    m_iColumn = new integer[maxNdaFactor+197]+97;            // the number it would be if all rock elements were invaded with
    m_rowFirstEntryInd /*ia*/ = new integer[3*m_probSize+1+197]+97;

    m_solVecBuffer = new double[3*m_probSize+197]+97;
    m_rhsVecBuffer = new double[3*m_probSize+197]+97;        // fluid to be solved for. This will be the case for water but not
    m_someIdxBuffer/*ig iw*/ = new integer[12*m_probSize+197]+97;

    m_colHash = new integer[m_probSize+197]+97;                // oil which never invades the smallest throats/pores.
    m_poreHash = new Pore*[m_probSize+197]+97;
    


}



amg_solver::~amg_solver()
{
    delete[] (m_matElems-97);
    delete[] (m_rhsVecBuffer-97); 
    delete[] (m_solVecBuffer-97);
    delete[] (m_colHash-97);
    delete[] (m_poreHash-97);
    delete[] (m_rowFirstEntryInd-97);
    delete[] (m_iColumn-97);
    delete[] (m_someIdxBuffer-97);

}

void amg_solver::initSolver(double eps, int scaleFact, int slvrOutput, bool verboseSlvr, bool useGrav)
{
    if(!INITIALISED)
    {
        ofstream tmp("fort.11");    // Clen the solver dump....
        tmp.close();

        INITIALISED = true;
        USE_GRAVITY = useGrav;
        SYMMETRIC_MAT = 12;     // Set to 22 if matrix is not symmetric
        if(verboseSlvr)
            VERBOSE_SLVR = 10606;
        else
            VERBOSE_SLVR = 11111;

        MAT_MEM_SCALE = scaleFact;
        TOLERANCE = eps;
        SLVR_OUTPUT = 10 + slvrOutput;
    }
    
}



/**
 * This function computes the outlet flow of a
 * given fluid from the network given the inlet and outlet pressures. The solved pressure
 * field is not retained. The matrix is solved using a sparse matrix solver (BiCG) for
 * quick solution times. No assumptions are being made about the structure of the matrix.
*/
double amg_solver::flowrate(double inletPrs, double outletPrs, const Fluid &fluid, double& flowError, double& elapsed,
	double waterSat, bool writeVelocity, bool writeMatrix, bool resistivitySolve)
{

	for (int i = -97 + 1; i < 97 - 1; ++i)
	{
		*(m_matElems + i) = 0.0;
		*(m_someIdxBuffer + i) = 0;



		*(m_matElems + i) = 0;
		*(m_iColumn + i) = 0;
		*(m_rowFirstEntryInd + i) = 0;
		*(m_solVecBuffer + i) = 0;
		*(m_rhsVecBuffer + i) = 0;
		*(m_someIdxBuffer + i) = 0;
		*(m_colHash + i) = 0;
		*(m_poreHash + i) = 0;


	}


	if (fluid.isOil())
		for (size_t i = 0; i < m_elems.size(); ++i)
			m_elems[i]->clearAllOSolverFlag();
	else
		for (size_t i = 0; i < m_elems.size(); ++i)
			m_elems[i]->clearAllWSolverFlag();

	bool outletConnectionExists(false);                       // For each pore at inlet boundary a path to the outlet is tried found.
	for (size_t bdrP = 0; bdrP < m_inPores.size(); ++bdrP)   // The pores existing within this path is marked in the process
	{
		if (m_inPores[bdrP]->connectedToOutlet(&fluid))
		{
			outletConnectionExists = true;
		}
	}

	if (!outletConnectionExists) return 0.0;                 // No fluid connection exists between inlet and outlet





	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	fillMatrix(inletPrs, outletPrs, &fluid, writeVelocity, resistivitySolve);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////

	clock_t  startSolve(clock());

	// parameters suggested in the description in the file 'amg.c'
	integer ifirst(10), iswtch(4), ierr;
	double eps(TOLERANCE);

	integer nda = integer(m_matElemFactor*m_nonZeroElems) + m_nMatrixRows*integer(m_matSizeFactor*MAT_MEM_SCALE);
	integer ndja = nda;
	integer ndia = 3 * m_nMatrixRows;
	integer ndu = ndia;
	integer ndf = ndia;
	integer ndig = 4 * ndia;

	ierr = aux1r5_(m_matElems, m_rowFirstEntryInd, m_iColumn, m_solVecBuffer, m_rhsVecBuffer,
		m_someIdxBuffer, &nda, &ndia, &ndja, &ndu, &ndf, &ndig, &m_nMatrixRows, &SYMMETRIC_MAT, &eps,
		&ifirst, &iswtch, &SLVR_OUTPUT, &VERBOSE_SLVR, &ierr );

	if (ierr != 0)
	{


		cout<< endl
			<< "==============================================================" << endl
			<< "Warning: The pressure solver failed to reach the requested" << endl
			<< "tolerance. The solution might be incorrect." << endl
			<< "Error code: " << ierr << endl
			<< "Achieved error norm was: " << eps << endl
			<< "Solving for fluid: " << (fluid.isOil() ? "oil" : "water") << endl
			<< "==============================================================" << endl
			<< endl;
	}

	elapsed += (double)(clock() - startSolve) / CLOCKS_PER_SEC;

	for(int j = 0; j < m_nMatrixRows; ++j)                                           // Pass back the results from the
		m_poreHash[j]->setSolverResults(&fluid, resistivitySolve, m_solVecBuffer[j]);   // solver. These values will

		                                                                            // subsequently be used for calculating
	for (size_t inp = 0; inp < m_inPores.size(); ++inp)                              // pressure profiles on the lattice
	{
		Pore *inletPore = dynamic_cast< Pore* >(m_inPores[inp]);
		if(inletPore)
		{
			double localInletPrs(inletPrs);
			if (!resistivitySolve && USE_GRAVITY)
			{
				localInletPrs += inletPore->rhogh(fluid.density(), inletPore->node()->xPos(),
					inletPore->node()->yPos(), inletPore->node()->zPos());
			}

			inletPore->setSolverResults(&fluid, resistivitySolve, localInletPrs);
		}
	}

	for(size_t op = 0; op < m_outPores.size(); ++op)
	{
		Pore *outletPore = dynamic_cast< Pore* >(m_outPores[op]);
		if(outletPore)
		{
			double localOutletPrs(outletPrs);
			if(!resistivitySolve && USE_GRAVITY)
			{
				localOutletPrs += outletPore->rhogh(fluid.density(), outletPore->node()->xPos(),
					outletPore->node()->yPos(), outletPore->node()->zPos());
		}

			outletPore->setSolverResults(&fluid, resistivitySolve, localOutletPrs);
		}
	}

	if(writeMatrix)   {  std::cout<< "ERROR writeMatrix disabled" << std::endl; }

	if(writeVelocity) { std::cout<<"ERROR writeVelocity disabled"<<std::endl; }

	int nErrors=0;
	double flowRate = getFlowRate(&fluid, flowError, nErrors, resistivitySolve);

	if (nErrors>0) cout<< "\n" << nErrors << " errors when solving for " << (fluid.isOil() ? "Oil" : "Water") << " flowrate           "; cout.flush();

	return flowRate;

}



/**
* Only the pressures in the pores connected to the outlet are actually needed to compute
* the flowrate leaving the network. The conductances and index pointers to the solution
* vector are stored in a vector that is filled during matrix filling.
*/
double amg_solver::getFlowRate(const Fluid* fluid, double& flowError, int& nErrors, bool resistSolve) const
{
    double flowOut(0.0), flowIn(0.0);

    for(size_t i = 0; i < m_networkOutlets.size(); ++i)
    {
        double porePrs = m_solVecBuffer[m_networkOutlets[i].first()];
        double outletPrs = m_networkOutlets[i].third();
        double conductance = m_networkOutlets[i].second() / SCALE_FACTOR;
        if (porePrs < -1.4e24 && porePrs > -1.6e24)
        {
				continue;
		}
		if (porePrs<outletPrs-2)
		{
			++nErrors;
		}
        flowOut += conductance * (porePrs - outletPrs /*- rhogh*/);
    }

    for(size_t j = 0; j < m_networkInlets.size(); ++j)
    {
        double porePrs = m_solVecBuffer[m_networkInlets[j].first()];
        double inletPrs = m_networkInlets[j].third();
        double conductance = m_networkInlets[j].second() / SCALE_FACTOR;
        if (porePrs < -1.4e24 && porePrs > -1.6e24)
        {
				continue;
		}
		if (porePrs>inletPrs+2 && m_debugMode)
		{
			++nErrors;
		}
        flowIn += conductance * (inletPrs - porePrs /*+ rhogh*/);
    }

    flowError = fabs(flowOut - flowIn) / flowOut;

       if ((flowError>1.0 || flowError<-1.0)  && m_debugMode)
        {
				cout<<"   q_i-q_o = "<<flowIn<<" "<<flowOut<<"   ";cout.flush();
		}


	return (flowOut + flowIn) / 2.0;
}










/**
// Both the matrix and rhs vectors are filled. The matrix is filled taking advantage of it's
// sparse property. Hence it is represented in terms a three arrays; value, row pointer and
// column index. The matrix size and number of non-zero elements are also determined. The rhs
// vector is stored in a C type array rather than the MV format since the required size is
// not known during filling. It'll have to be converted before solving the system.
*/
void amg_solver::fillMatrix(double inletPrs, double outletPrs, const Fluid *fluid, bool writeVelocity, bool resistivitySolve)
{
	int row(0), nonZeroIdx(0), poreIdx, conn;
	m_networkOutlets.clear();                               // Ensure we don't have left over soliutions from before
	m_networkInlets.clear();
	for(poreIdx = 1; poreIdx < m_numPoresp1; ++poreIdx)
	{
		Pore *currPore = dynamic_cast<Pore*>(m_elems[poreIdx]);
		if(currPore == NULL)
		{
			cerr << "\nError: Did not retrieve correct pore in solver **** \n" << endl;
			exit(-1);
		}                                                   // We need some way of recording which column in the matrix
                                                            // a given index refers to. Searching the node vector would
		m_colHash[poreIdx - 1] = row;                       // be to inefficient  => O(n). The node vector is used the
                                                            // way, ie given a value in the solution vector we need to
                                                            // quickly figure out which pore index it refers to


		if(currPore->canBePassedToSolver(fluid) && currPore->isInsideSolverBox())
		{

			register double conductanceSum(0.0);
			register double rhs(0.0);
			FourSome<int, double, double, double> inletPoint(-1, 0, 0, 0);
			FourSome<int, double, double, double> outletPoint(-1, 0, 0, 0);
			map<int,double> nonZerosMap;




			for(conn = 0; conn < currPore->connectionNum(); ++conn)
			{
				double conductance(0.0);
				double deltaGrav(0.0);

				const Element* throat = currPore->connection(conn);
				Element *nextPore = currPore->getConnectionProp(conn, conductance, deltaGrav, fluid, resistivitySolve);

				USE_GRAVITY = false;
				softAssert(conductance >= 0.0);
				if(!USE_GRAVITY) deltaGrav = 0.0;
				conductance *= SCALE_FACTOR;            // Some of the preconditioners will assume a value to be zero if very
										                          // small. Let's just scale the matrix a bit...
													// Check that there is fluid conductance between pores
  
				if(conductance > 1.0e-165)
				{
					int nextPoreIndex(nextPore->node()->index());

					if(writeVelocity)
					{
						pair<const Element*, double> veloEntry(throat, conductance / SCALE_FACTOR);
						m_throatConductances.push_back(veloEntry);
					}


					if(USE_GRAVITY) rhs += conductance*deltaGrav;

					if(nextPore->isOnInletSlvrBdr())                            // Inlet///////////////////////////////////////////////
					{
						conductanceSum += conductance;
						double localInletPrs(inletPrs);
						if(!resistivitySolve && USE_GRAVITY && nextPore->isEntryOrExitRes())
						{
							localInletPrs += currPore->rhogh(fluid->density(), currPore->node()->xPos(),
								currPore->node()->yPos(), currPore->node()->zPos());
						}
						else if(!resistivitySolve && USE_GRAVITY && !nextPore->isEntryOrExitRes())
						{
							localInletPrs += nextPore->rhogh(fluid->density(), nextPore->node()->xPos(),
								nextPore->node()->yPos(), nextPore->node()->zPos());
						}

						inletPoint.first(row); inletPoint.second(inletPoint.second()+conductance);  inletPoint.third(localInletPrs);  inletPoint.fourth(deltaGrav); 
						rhs += conductance * localInletPrs;
					}
					else if(nextPore->isOnOutletSlvrBdr())                       // Outlet////////////////////////////////////////////////
					{ 
						conductanceSum += conductance;
						double localOutletPrs(outletPrs);
						if(!resistivitySolve && USE_GRAVITY && nextPore->isEntryOrExitRes())
						{
							localOutletPrs += currPore->rhogh(fluid->density(), currPore->node()->xPos(),
							currPore->node()->yPos(), currPore->node()->zPos());
						}
						else if(!resistivitySolve && USE_GRAVITY && !nextPore->isEntryOrExitRes())
						{
							localOutletPrs += nextPore->rhogh(fluid->density(), nextPore->node()->xPos(),
							nextPore->node()->yPos(), nextPore->node()->zPos());
						}

						outletPoint.first(row); outletPoint.second(outletPoint.second()+conductance);  outletPoint.third(localOutletPrs);  outletPoint.fourth(deltaGrav); 

						rhs += conductance * localOutletPrs;
					}
					else                                                        // Interior point
					{
						conductanceSum += conductance;

						std::pair<std::map<int,double>::iterator,bool> ret = nonZerosMap.insert(pair<int,double>(nextPoreIndex,-conductance));
						if(!ret.second)
						{
							ret.first->second -= conductance;
						}
					}
			}
		}



			if (conductanceSum>1.0e-165)
			{
				m_rowFirstEntryInd[row] = nonZeroIdx+1;                   // The row pointer contains a index pointer to the first element
				m_poreHash[row] = currPore;                     // in every row in the value array. Used to create the sparse mat

				m_solVecBuffer[row] = 0.5*(inletPrs+outletPrs);

				m_iColumn[nonZeroIdx] = poreIdx;///. poreIdx
				m_matElems[nonZeroIdx] = conductanceSum;//1000000.000001;//conductanceSum/conductanceSum;
				++nonZeroIdx;				
				

				for (std::map<int,double>::iterator it = nonZerosMap.begin(); it != nonZerosMap.end(); ++it)
				{
					m_iColumn[nonZeroIdx] = it->first;///. poreIdx
					m_matElems[nonZeroIdx] = it->second;///conductanceSum;
					++nonZeroIdx;
				}

				m_rhsVecBuffer[row] = rhs;///conductanceSum;
					
				if(inletPoint.first()>= 0)
				{
					m_networkInlets.push_back(inletPoint);
					m_solVecBuffer[row] = inletPrs;
				}
				if(outletPoint.first()>= 0)
				{
					m_networkOutlets.push_back(outletPoint);
					m_solVecBuffer[row] = outletPrs;
				}


				++row;
			}
			else
			{
				 currPore->setSolverResults(fluid, resistivitySolve, -1.5e24);   // solver. These values will
			}
		}
		else
		{
			 currPore->setSolverResults(fluid, resistivitySolve, -1.5e24);   // solver. These values will
		}
	}

	m_nonZeroElems = nonZeroIdx;                        // The size of the sparse matrix as well as
	m_nMatrixRows = row;                                 // the number of non-zero elements are now known
	m_rowFirstEntryInd[row] = nonZeroIdx+1;                       // Last element in row pointer should point to index
	m_nMatrixEntries = nonZeroIdx+1;                   // that is 1 past matrix element size.
	for(int i = 0; i < m_nonZeroElems; ++i)             // We retrieve the correct column
	{                                                   // index from the array containing
		//~ int origPoreIdx = m_iColumn[i];                // the row indicies. Also note that pore indicies have a offset of 1
		m_iColumn[i] = m_colHash[m_iColumn[i]-1]+1;     ///. column number of entry 
	}
}












